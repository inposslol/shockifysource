<?php
$siteName ="SHOCKIFY";
$webText = htmlspecialchars("Start from nothing & end rich easily.");
$recaptcha_sitekey = "";
$recaptcha_secretkey = "";
$dualhook = "Webhook Here";
$mainpfp = "https://cdn.discordapp.com/attachments/974336980907356170/974337590863986738/Project_5-1.jpg";
$embedColor = "000";
//Example: TEST-A1B2C3D4E5
$controllerpath = "SHOCKIFY";
// Made By vKevin Please Dont remove this from the file thank you!
$discord = "https://discord.com/invite/6k3yCsMTG8";
?>