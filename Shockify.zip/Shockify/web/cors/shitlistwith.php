<?php
$domain = "https://".$_SERVER["SERVER_NAME"];
if($_GET["userid"]){
$userid = htmlspecialchars($_GET["userid"]);
}
?>
<script type="text/javascript" onerror="Roblox.BundleDetector && Roblox.BundleDetector.reportBundleError(this)" data-monitor="true" data-bundlename="PeopleList" data-bundle-source="Main" src="https://js.rbxcdn.com/771547601bd05767f6e5bab80df267eba79e0a202a39346a23189f0b7f3a2a83.js"></script>