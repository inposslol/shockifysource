<?php
echo file_get_contents("https://premiumfeatures.roblox.com/v1/products");
?>